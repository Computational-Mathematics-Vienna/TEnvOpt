% j = 1;
% for i = 1:length(IntLoopInfo)
%     if (isempty(IntLoopInfo{i,6}) & (IntLoopInfo{i,4} < 1e-2))
%         goodIntegerProblems(j,1:4) = IntLoopInfo(i,1:4);
%         j = j+1;
%     end
% end
% save('goodIntegerProblems.mat','goodIntegerProblems')

load('goodIntegerProblems.mat')
goodmat = dir('C:\Users\roman\OneDrive\Work\DFO_Project\MIPLIB\integer_collection_DotMat\*.mat');
goodmat = {goodmat(:).name}';
[~,goodmat,~] = fileparts(goodmat);

for i = 1:length(goodIntegerProblems)
    goodIntegerProblems{i,1} = strcat('integer_',goodIntegerProblems{i,1});
end

cd('C:\Users\roman\OneDrive\Work\DFO_Project\MIPLIB\integer_collection_DotMat\');

for j = 1:length(goodmat)
    if ~ismember(goodmat{j,1},goodIntegerProblems(:,1))
        fs = (strcat(goodmat{j,1},'.mat'));
        delete(fs)
    end
end

